
export const products = [
{
id:1,
name:"Glow Serum",
price:29,
image:"https://images.unsplash.com/photo-1608248597279-f99d160bfcbc"
},
{
id:2,
name:"Radiant Cream",
price:35,
image:"https://images.unsplash.com/photo-1585238342028-4f6f0c3a6a9d"
},
{
id:3,
name:"EvenifGlow Mask",
price:22,
image:"https://images.unsplash.com/photo-1596755389378-c31d21fd1273"
}
]
