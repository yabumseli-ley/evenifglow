
import Link from "next/link"

export default function Navbar(){

return(

<nav className="border-b bg-white">

<div className="max-w-6xl mx-auto px-6 py-4 flex justify-between">

<Link href="/" className="font-bold text-xl">
EvenifGlow
</Link>

<div className="flex gap-6">

<Link href="/shop">
Shop
</Link>

<Link href="/cart">
Cart
</Link>

</div>

</div>

</nav>

)
}
