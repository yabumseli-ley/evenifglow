
export default function ProductCard({product}){

return(

<div className="bg-white p-4 rounded-xl shadow hover:shadow-lg">

<img src={product.image} className="rounded-lg"/>

<h3 className="mt-3 font-semibold">
{product.name}
</h3>

<p className="text-glow font-medium">
${product.price}
</p>

<button className="mt-3 w-full bg-glow text-white py-2 rounded-lg">
Add to Cart
</button>

</div>

)
}
