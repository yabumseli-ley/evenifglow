
export default function Cart(){

return(

<main className="max-w-4xl mx-auto px-6 py-20">

<h1 className="text-3xl font-bold">
Your Cart
</h1>

<p className="mt-6 text-gray-600">
Cart functionality can be connected with Stripe checkout.
</p>

</main>

)
}
