
import Link from "next/link";

export default function Home(){
return(

<main className="max-w-6xl mx-auto px-6 py-20 text-center">

<h1 className="text-5xl font-bold">
EvenifGlow
</h1>

<p className="mt-6 text-gray-600">
Modern skincare that makes you glow.
</p>

<Link
href="/shop"
className="inline-block mt-8 bg-glow text-white px-8 py-3 rounded-xl"
>
Shop Now
</Link>

</main>

)
}
