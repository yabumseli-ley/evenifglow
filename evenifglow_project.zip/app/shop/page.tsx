
import {products} from "../../lib/products"
import ProductCard from "../../components/ProductCard"

export default function Shop(){

return(

<main className="max-w-6xl mx-auto px-6 py-16">

<h1 className="text-3xl font-bold mb-10">
Shop Products
</h1>

<div className="grid grid-cols-1 md:grid-cols-3 gap-8">

{products.map((p)=>(
<ProductCard key={p.id} product={p} />
))}

</div>

</main>

)
}
